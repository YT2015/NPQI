function y = mapminmax(x,ymin,ymax)
xmin = min(x);
xmax = max(x);
y = (ymax-ymin)*(x-xmin)/(xmax-xmin) + ymin;
end