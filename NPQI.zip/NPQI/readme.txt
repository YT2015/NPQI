This is the code of NPQI proposed in the following paper:

Yutao Liu, Ke Gu, Xiu Li, and Yongbing Zhang, Blind Image Quality Assessment by Natural Scene Statistics and Perceptual Characteristics. ACM Trans. Multimedia Comput. Commun. Appl. 16, 3, Article 91 (September 2020), 91 pages. 

Please run demo.m